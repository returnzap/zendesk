#!/usr/bin/env bash
# Packages the Zendesk app for all environments and copies to HQ public directory.
# Usage: ./zendesk/build.sh <project_root>
set -euo pipefail

PROJECT_ROOT="${1:-.}"

declare -A HOSTS=(
    [production]="api.returnzap.com"
    [staging]="api.returnzap.dev"
    [dev]="api-local.returnzap.dev"
)

OUTPUT_DIR="$PROJECT_ROOT/hq/public/zendesk"
mkdir -p "$OUTPUT_DIR"

for ENV in production staging dev; do
    HOST="${HOSTS[$ENV]}"

    WORK_DIR=$(mktemp -d)
    trap "rm -rf $WORK_DIR" EXIT

    cp -r "$PROJECT_ROOT/zendesk/"* "$WORK_DIR/"
    rm -f "$WORK_DIR/build.sh" "$WORK_DIR/zcli.apps.config.json"

    # Replace placeholders in iframe.html (portable across macOS and Linux)
    perl -pi -e "s|__API_HOST__|$HOST|g" "$WORK_DIR/assets/iframe.html"
    perl -pi -e "s|__SECURE__|true|g" "$WORK_DIR/assets/iframe.html"

    # Replace API host in manifest
    jq --arg host "$HOST" \
       '.domainWhitelist = [$host] | .parameters[0].secure = true | .parameters[0].required = true' \
       "$WORK_DIR/manifest.json" > "$WORK_DIR/manifest.tmp" && mv "$WORK_DIR/manifest.tmp" "$WORK_DIR/manifest.json"

    # Validate and package
    cd "$WORK_DIR"
    zcli apps:validate
    zcli apps:package

    # Move output
    if [ "$ENV" = "production" ]; then
        FILENAME="returnzap-zendesk.zip"
    else
        FILENAME="returnzap-zendesk-${ENV}.zip"
    fi
    cp tmp/*.zip "$OUTPUT_DIR/$FILENAME"
    echo "✓ $ENV → $OUTPUT_DIR/$FILENAME"

    rm -rf "$WORK_DIR"
    cd "$PROJECT_ROOT"
done

echo ""
echo "All packages ready in $OUTPUT_DIR/"
